package task3_2;

public interface LeftSide {
	double f(double x);
}
