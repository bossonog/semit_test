package task3_2;

public class Solver {
	static double solver(double a, double b, double step, LeftSide ls) {
		double min = ls.f(a);
		double i;
		for (i=a; i<b; i+=step) {
			if (ls.f(i)<ls.f(min)) min = i;
		}
		return ls.f(min);
	}
}
