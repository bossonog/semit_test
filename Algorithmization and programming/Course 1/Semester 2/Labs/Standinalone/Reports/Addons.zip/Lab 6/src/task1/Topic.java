package task1;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Topic implements Comparable<Topic> {
	private int[] date;
	private String subject;
	private int students;
	public Topic(int[] date, String subject, int students) {
		this.date = date;
		this.subject = subject;
		this.students = students;
	}
	public int[] getDate() {
		return date;
	}
	public void setDate(int[] date) {
		this.date = date;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public int getAmount() {
		return students;
	}
	public void setAmount(int amount) {
		this.students = amount;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj==null || !(obj instanceof Topic))
			return false;
		Topic test = (Topic) obj;
		return Arrays.equals(test.getDate(), (getDate())) &&
				test.getAmount() == getAmount() &&
				test.getSubject() == getSubject();
		
	}
	@Override
	public int compareTo(Topic p) {
		return Integer.compare(getAmount(),p.getAmount());
	}
	@Override
	public String toString() { //overloading toString() method
		return ("Date: " + date[0] + "." + date[1] + "." + date[2] + " Subject: " + subject + " Students: " + students);
	}
	
    public boolean containsWord(String word) {
        StringTokenizer st = new StringTokenizer(subject);
        String s;
        while (st.hasMoreTokens()) {
            s = st.nextToken();
            if (s.toLowerCase().equals(word.toLowerCase())) {
                return true;
            }
        }
        return false;
    }
}
