package task3_2;

class MyEquation implements LeftSide {
   public double f(double x) {
        return x * x;
    }
   
	public static void main(String[] args) {
		System.out.println(Solver.solver(-5, 5, 1, new 	MyEquation()));
	}
}
