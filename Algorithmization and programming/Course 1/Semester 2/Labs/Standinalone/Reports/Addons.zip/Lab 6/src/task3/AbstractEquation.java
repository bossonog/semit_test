package task3;

public abstract class AbstractEquation {
	abstract double f (double x);
	
	double solve (double a, double b, double step) {
		double min = f(a);
		double i;
		for (i=a; i<b; i+=step) {
			if (f(i)<f(min)) min = i;
		}
		return f(min);
	}
}