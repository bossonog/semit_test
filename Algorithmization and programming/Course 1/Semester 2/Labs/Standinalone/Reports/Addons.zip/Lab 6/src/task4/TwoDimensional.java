package task4;

public class TwoDimensional extends AbstractArrayOfPoints{
	private double[][] arr = {};
	
	@Override
	public void setPoint(int i, double x, double y) {
		if (i<count()) {
			arr[i][0]=x;
			arr[i][1]=y;
		}
	}
	@Override
	public double getX(int i) {
		return arr[i][0];
	}

	@Override
	public double getY(int i) {
		return arr[i][1];
	}

	@Override
	public int count() {
		return arr.length;
	}

	@Override
	public void addPoint(double x, double y) {
		double[][] arr1 = new double[arr.length+1][2];
		for (int i=0; i<arr.length; i++) {
			System.arraycopy(arr[i], 0, arr1[i], 0, arr[i].length);
			//System.arraycopy(src, srcPos, dest, destPos, length);
		}
		arr1[arr.length][0] = x;	
		arr1[arr.length][1] = y	;	
		arr = arr1;
	}

	@Override
	public void removeLast() {
		if (count() == 0) return;
		double[][] arr1 = new double[arr.length-1][2];
		for (int i=0; i<arr.length; i++) {
			System.arraycopy(arr[i], 0, arr1[i], arr.length, arr[i].length);
		}
		arr=arr1;
	}
	public static void main(String[] args) {
		new TwoDimensional().test();
	}
}
