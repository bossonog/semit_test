package task2;

class Human {
	private String name;
	private String surname;
	private int age;
	
	public Human(String name, String surname, int age) {
		super();
		this.name = name;
		this.surname = surname;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Human [name=" + name + ", surname=" + surname + ", age=" + age + "]";
	}
}

class Student extends Human{
	private int year;

	public Student(String name, String surname, int age, int year) {
		super(name, surname, age);
		this.year = year;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	@Override
	public String toString() {
		return "Student [year of study=" + year + ", getName()=" + getName() + ", getSurname()=" + getSurname() + ", getAge()="
				+ getAge() + "]";
	}
} 
class Coworker extends Human{
	private int year;

	public Coworker(String name, String surname, int age, int year) {
		super(name, surname, age);
		this.year = year;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	@Override
	public String toString() {
		return "Coworker [Coworking years=" + year + ", getName()=" + getName() + ", getSurname()=" + getSurname() + ", getAge()="
				+ getAge() + "]";
	}
} 
class Citizen extends Human{
	private String city;

	public Citizen(String name, String surname, int age, String city) {
		super(name, surname, age);
		this.city = city;
	}

	public String getCity() {
		return city;
	}

	public void setYear(int year) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Citizen [City=" + city + ", getName()=" + getName() + ", getSurname()=" + getSurname() + ", getAge()="
				+ getAge() + "]";
	}
} 
	


public class Humans{
	public static void main(String[] args) {
		Human[] arr = {new Student("Steve", "Rogers", 100, 3),
				new Citizen("Tony", "Stark", 42, "Malibu"),
				new Coworker("Natasha", "Romanoff", 35, 3)};
		for (Human human : arr) {
			System.out.println(human);
		}
	}
}
