package task5;

public abstract class AbstractArrayOfPoints {
    public abstract void setPoint(int i, double x, double y);

    public abstract double getX(int i);

    public abstract double getY(int i);

    public abstract int count();

    public abstract void addPoint(double x, double y);

    public abstract void removeLast();

    public void sortByX() {
		for(int i=1;i<count();i++){
			for(int j=i; (j>0) && (getX(j-1) > getX(j)); j--){
				double x = getX(j);
				double y = getY(j);
				setPoint(j, getX(j-1), getY(j-1));
				setPoint(j-1, x, y);
			}
		}
    }


    @Override
    public String toString() {
        String s = "";
        for (int i = 0; i < count(); i++) {
            s += "x = " + getX(i) + " \ty = " + getY(i) + "\n";
        }
        return s + "\n";
    }

    public void test() {
        addPoint(22, 45);
        addPoint(4, 11);
        addPoint(30, 5.5);
        addPoint(-2, 48);
        System.out.println(this + "Sorted by X");
        sortByX();
        System.out.println(this);
    }


}