package task3;

public class SpecificEquation extends AbstractEquation{
	double f(double x) {
		return x*x;
	}
	public static void main(String[] args) {
		SpecificEquation se = new SpecificEquation();
		System.out.println(se.solve(-5, 5, 1));
	}
}