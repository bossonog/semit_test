package task1;
import java.util.StringTokenizer;
import java.util.Arrays;
import java.util.Comparator;

public class Subject {
	private Topic[] Practices;
	public Subject(Topic[] practices, String name, boolean exams) {
		//super();
		Practices = practices;
		this.name = name;
		this.exams = exams;
	}
	private String name;
	private boolean exams;
	public double getAverage() {
		double average=0;
		for (Topic practice: Practices) {
			average+=practice.getAmount();
		}
		return average/=Practices.length;
	}
	public Topic getMax() {
		Topic practice = Practices[0];
		for (int i=1; i<Practices.length; i++) {
			if(Practices[i].getAmount()>practice.getAmount()) {
				practice = Practices[i];
			}
		}
		return practice;
	}
	public Topic[] getPractices() {
		return Practices;
	}
	public static Topic[] addToArray(Topic[] arr, Topic item) {
		Topic[] newArr;
		if (arr!=null) {
			newArr = new Topic[arr.length+1];
			System.arraycopy(arr, 0, newArr, 0, arr.length);
		}
		else {
			newArr = new Topic[1];
		}
		newArr[newArr.length-1]=item;
		return newArr;
	}
	public void setPractices(Topic[] arr) {
		this.Practices = arr;
	}
	public boolean addPractice(Topic practice) {
		if (getPractices()!=null) {
			for (Topic p : Practices) {
				if (p.equals(practice)) {
					return false;
				}
			}
		}
		setPractices(addToArray(getPractices(), practice));
		return true;
	}
	public Topic[] findWord(String word) {
		System.out.println("Info about practice containing word " + word);
		Topic[] arr = null;
		for (Topic practice: Practices) {
			if (practice.containsWord(word)) {
				addToArray(arr, practice);
				System.out.println(practice);
			}
		}
		return arr;
	}
	public void sortByStudents() {
		Arrays.sort(Practices);
	}
	public void sortByTopic(){
		Arrays.sort(Practices, new CompareByTopic());
	}
	class CompareByTopic implements Comparator<Topic>{
		public int compare(Topic p1, Topic p2) {
			return Integer.compare(p1.getSubject().length(),p2.getSubject().length());
		}
	}
	public int practicesCount() {
        return Practices == null ? 0 : Practices.length;
    }
	public Topic getPractice(int i) {
		return Practices[i];
	}
	@Override
	public String toString() { //overloading toString() method
        String result = "Name: " + name + " Exams: " + exams + " Amount of practices: " + Practices.length;
        for (int i = 0; i < practicesCount(); i++) {
            result += "\n" + getPractice(i);
        }
        return result;
	}
	public static void main(String[] args) {
		Topic[] Practices = {
	            new Topic(new int []{10,1,2018}, "Deep First Search", 5),
	            new Topic(new int[]{17,1,2018}, "Bredth First Search", 6),
	        };
	        Subject sub = new Subject(Practices, "Algorithms & Data Structures", true);
	        
	        System.out.println("Students average amount: " + sub.getAverage());
	        System.out.println("Max amount of students practice: " + sub.getMax().getAmount() + " (" + sub.getMax().getSubject() + " topic)");
	        sub.findWord("Search");
	        
	        System.out.println("\nInfo about Subject object: \n" + sub);
	        
	        System.out.println("\nAdding new practices to Algorithms & Data Structures");
	        System.out.println(sub.addPractice(new Topic(new int[]{24,1,2018}, "Gift Wrapping Algorithm", 8)));
	        System.out.println(sub.addPractice(new Topic(new int[]{31,1,2018}, "Pseudorandom generators", 3)));
	        System.out.println(sub.addPractice(new Topic(new int[]{7,2,2018}, "Dynamic Programming", 8)));
	        System.out.println(sub.addPractice(new Topic(new int[]{7,2,2018}, "Dynamic Programming", 8)));
	        
	        sub.sortByStudents();
	        System.out.println("\nSorting by students amount: \n" + sub);
	        sub.sortByTopic();
	        System.out.println("\nSorting by the length of a topic name: \n" + sub);
	}

}
