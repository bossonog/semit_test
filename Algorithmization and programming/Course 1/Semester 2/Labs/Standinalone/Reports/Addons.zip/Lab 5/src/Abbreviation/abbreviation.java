package Abbreviation;
import java.util.Scanner;
import java.util.StringTokenizer;

public class abbreviation {
	private static String input;
	private static String result="";
	public static void abbr() {
		StringTokenizer st = new StringTokenizer(input);
		while (st.hasMoreTokens()) {
			result += st.nextToken().substring(0,1).toUpperCase();
		}
	}
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		input = s.nextLine();
		abbr();
		System.out.print(result);
	}

}
