package String;
import java.util.Scanner;

public class String {
	static java.lang.String input;
	public static void add(int n) {
		while (input.length()<n) {
			input += ".";
		}
	}
	public static void main(java.lang.String[] args) {
		 Scanner s = new Scanner(System.in);
		 input = s.nextLine();
		 add(5);
		 System.out.println(input);
	}

}
