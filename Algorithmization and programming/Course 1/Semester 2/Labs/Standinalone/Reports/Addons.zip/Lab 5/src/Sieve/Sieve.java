package Sieve;
import java.util.Scanner;
import java.util.Arrays;
public class Sieve {
	
	static int n=300;
	static int[] primes = new int[n];
	
	public static void main(String[] args) {
		for (int i=0; i<n; ++i) {
			primes[i]=(i);
		}
	    for (int i = 2; i < primes.length; ++i) {
	        if ((i<n) && (primes[i]!=0) ){
	            for (int j = 2; i * j < primes.length; ++j) {
	                primes[i * j] = 0;
	            }
	        }
	    }
	    for (int i:primes) if (i>0) System.out.print(i + "  ");
	}

}