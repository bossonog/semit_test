package Equation;

public class Equation {
	private static double x1;
	private static double x2;
	public static int solve(int a, int b, int c) {
		if (a!=0) {
			double d = b*b - 4*a*c;
			if (d<0) return 0;
			else
			{
				x1 = (-b + Math.sqrt(d)) / 2 / a;
				x2 = (-b - Math.sqrt(d)) / 2 / a;
				if (x1 == x2) return 1;
				return 2;
			}
		}
		else {
			if(b!=0) {
				x1 = -c/b;
				return 1;
			}
			else {
				if (c!=0) return 0;
				return -1;
			}
		}
	}
	public static double getX1() {
		return x1;
	}
	public static double getX2() {
		return x2;
	}
	public static void main(String[] args) {
		int a=1;
		int b=5;
		int c=4;
		solve(a,b,c);
		System.out.print(getX1() + "  " + getX2());
	}

}
