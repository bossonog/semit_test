package Fibonacci;

public class Fibonacci {
	private static long[] arr = new long[100];
	private static int size = 0;

	public static long fib(int n) {
		if (n<size) {
			return arr[n];
		}
		generate(n);
		return arr[n];
	}	
	
	public static void generate (int n) {
		if (size==0) {
			arr[0]=1;
			arr[1]=1;
			size = 2;
			do {
				arr[size]=(fib(size-2)+fib(size-1));
				System.out.print(arr[size]+ "  ");
				size++;
			} while(fib(size-2)+fib(size-1)<92);
		}
		else {
			do {
				arr[size]=(fib(size-2)+fib(size-1));
				System.out.print(arr[size]+ "  ");
				size++;
			} while(size<=n);
		}
		System.out.println();
	}
	public static void main(String[] args) {
		fib(0);
		System.out.println(fib(2));
		System.out.println(fib(10));
		System.out.println(fib(15));
		System.out.println(fib(20));
	}

}
