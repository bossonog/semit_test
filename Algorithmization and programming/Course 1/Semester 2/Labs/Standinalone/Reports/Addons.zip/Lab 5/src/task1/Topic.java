package task1;
import java.util.StringTokenizer;

public class Topic {
	private int[] date;
	private String subject;
	private int students;
	public Topic(int[] date, String subject, int students) {
		this.date = date;
		this.subject = subject;
		this.students = students;
	}
	public int[] getDate() {
		return date;
	}
	public void setDate(int[] date) {
		this.date = date;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public int getAmount() {
		return students;
	}
	public void setAmount(int amount) {
		this.students = amount;
	}
	public void fullInfo() {
		System.out.println("Date: " + date[0] + "." + date[1] + "." + date[2] + " Subject: " + subject + " Students: " + students);
	}
    public boolean containsWord(String word) {
        StringTokenizer st = new StringTokenizer(subject);
        String s;
        while (st.hasMoreTokens()) {
            s = st.nextToken();
            if (s.toLowerCase().equals(word.toLowerCase())) {
                return true;
            }
        }
        return false;
    }
}
