package Sorting;
import java.util.Arrays;

public class Sorting {
	public static void sorting(int[] a) {
		for (int counter=0; counter<a.length; counter++) {
			int min = counter;
			for (int i=counter; i<a.length; i++) {
				if (a[i]<a[min]) min = i; 
			}
			int temp = a[min];
			a[min] = a[counter];
			a[counter] = temp;
		}
	}
	public static void main(String[] args) {
		int n=10;
		int[] a = new int[n];
		System.out.println("Unsorted array: ");
	      for (int i = 0; i < n; i++) {
	            a[i] = (int) (Math.random() * 100);
	            System.out.print(a[i] + " ");
	        }
	      System.out.println();
	      sorting(a);
	      System.out.println("Sorted array: \n" + Arrays.toString(a));
	}

}
