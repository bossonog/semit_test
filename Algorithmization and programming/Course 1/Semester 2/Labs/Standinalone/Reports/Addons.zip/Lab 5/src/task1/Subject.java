package task1;
import java.util.StringTokenizer;

public class Subject {
	  private Topic[] Lectures;
	  public Subject(Topic[] lectures, String name, String family) {
	    super();
	    Lectures = lectures;
	    this.name = name;
	    this.family = family;
	  }
	  private String name;
	  private String family;
	  public double getAverage() {
	    double average=0;
	    for (Topic lecture: Lectures) {
	      average+=lecture.getAmount();
	    }
	    return average/=Lectures.length;
	  }
	  public void LastLetter() {
		  System.out.print("Full name: " + family);
		  System.out.println(" Last letter: " + family.substring(family.length()-1,family.length()));
	  }
	  public Topic getMin() {
	    Topic lecture = Lectures[0];
	    for (int i=1; i<Lectures.length; i++) {
	      if(Lectures[i].getAmount()>lecture.getAmount()) {
	        lecture = Lectures[i];
	      }
	    }
	    return lecture;
	  }
	  public void findWord(String word) {
	    System.out.println("Info about lecture containing word " + word);
	    for (Topic lecture: Lectures) {
	      if (lecture.containsWord(word)) {
	        lecture.fullInfo();
	      }
	    }
	  }
	  public static void main(String[] args) {
	    Topic[] Lectures = {
	              new Topic(new int []{10,1,2018}, "Bubble Sorting", 5),
	              new Topic(new int[]{17,1,2018}, "Merge Sorting", 6),
	          };
	          Subject sub = new Subject(Lectures, "Algorithms & Data Structures", "DEn LOh");
	          
	          System.out.println("Students average amount: " + sub.getAverage());
	          System.out.println("Min amount of students lecture: " + sub.getMin().getAmount() + " (" + sub.getMin().getSubject() + " topic)");
	          sub.findWord("Sorting");
	          sub.LastLetter();
	  }
}