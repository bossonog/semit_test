#include <iostream>
using std::cout;
using std::ostream;
using std::endl;

class Numbers
{	
	friend Numbers operator+(Numbers & a, Numbers & b) {
		//if (true){
			Numbers c(a.value+b.value);
			return c;
		//}
	}
public:
	int value;
	Numbers(){}
	Numbers(int value) : value(value) {cout << "Created " << this << endl;}
	~Numbers(){
		cout << "Deleted " << this << " / " << value << endl;
	}
};

int main(){
	Numbers a(5);
	Numbers b(4);
	Numbers c = a+b;
	system("pause");
}
