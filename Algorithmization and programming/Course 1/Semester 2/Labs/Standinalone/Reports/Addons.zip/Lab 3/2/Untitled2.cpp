//#include <iostream>
//#include <queue> 
//#include <string>
//using std::priority_queue;
//using std::cout;
//using std::endl;
//
//using std::string;
//
//class Country
//{
//private:
//    string name;
//    double square;
//    long   population;
//public:
//    Country() : name(""), square(1), population(0) { }
//    Country(string n, double s, long p) : name(n), square(s), population(p) { }
//    string getName()           const { return name; }
//    double getSquare()         const { return square; }
//    long   getPopulation()     const { return population; }
//    void   setName(string value) { name = value; };
//    void   setSquare(double value) { square = value; }
//    void   setPopulation(long value) { population = value; }
//    double density() const { return population / square; }
//};
//
//bool operator<(const Country& c1, const Country& c2)
//{
//    return c1.density() < c2.density();
//}
//
//int main()
//{
//    Country c0("Ukraine", 603700, 42539000);
//    Country c1("France", 544000, 57804000);
//    Country c2("Sweden", 450000, 8745000);
//    Country c3("Germany", 357000, 81338000);
//    priority_queue<Country> cq;
//    cq.push(c0);
//    cq.push(c1);
//    cq.push(c2);
//    cq.push(c3);
//    while (cq.size())
//    {
//        cout << cq.top().getName() << endl;
//        cq.pop();
//    }
//    return 0;
//}
