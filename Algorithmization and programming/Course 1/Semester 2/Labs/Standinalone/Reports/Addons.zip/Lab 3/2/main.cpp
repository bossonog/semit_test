#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;
class Student{
private:
	unsigned int rbook;	
	string lname;
	vector<int> marks;
public:
	Student(){}
	Student(unsigned int rbook, string lname, vector<int> marks) : rbook(rbook), lname(lname), marks(marks){}
	
	unsigned int getRbook() const{return rbook;}
	string getName() 		const{return lname;}
	vector<int> getMarks() 	const{return marks;}
	
	double Average() const{
		int sum=0;
		for (int i : marks) sum+=i;
		return  (double)sum/marks.size();
	}
	void search (){
		if (lname.length()>7){
			cout << lname << " / " << rbook << " / ";
			for (int x : marks) cout << x << " ";
			cout << endl;
		}
	}	
	bool operator()(const Student& s1, const Student& s2) const{
        return s1.Average() < s2.Average();
    }
	void setRbook(int value){rbook=value;}
	void setName(string value){lname=value;}
	void setRbook(vector<int> value){marks=value;}
};
    
class Group{
private:
	friend ostream& operator<<(ostream& out, Group& gr){
		for (Student i : gr.a){
			out << i.getName() << " / " << i.getRbook() << " / ";
			for (int x : i.getMarks()) cout << x << " ";
			cout << " / Average grade: " << i.Average() << endl;
		}
		return out;
	}
	friend istream& operator>>(istream& in, Group& gr){
		cout << "Enter number of record book, last name, and 6 marks: " << endl;
		int rbook;
		string lname;
		vector<int> marks;
		int mark;
		cin >> rbook >> lname;
		for (int i=0; i<6; i++){
			cin >> mark;
			marks.push_back(mark);
		}
		gr.a.push_back(Student(rbook, lname, marks));
	}
	vector<Student> a;
public:
	Group(){}
	Group(vector<Student> a) : a(a) {};
	void search(){
		for_each(a.begin(),a.end(),mem_fun_ref(&Student::search));
	}
	void sorting(){
		sort(a.begin(), a.end(), Student());
	}
};

int main() {
	Student Zar(123,"Zarchenko",{4,5,4,5,4,4});
	Student Ser(451,"Sergeev",{4,5,4,5,4,4});
	Student Bez(270,"Bezkrovniy",{5,5,4,5,4,5});
	Student Sin(54,"Sinetutov",{2,2,2,2,2,2});
	
	Group gr(vector<Student>{Zar,Ser,Bez,Sin});
	cout << "Using for_each with condition determined in class Student (last name contains more than 7 letters): " << endl;
	gr.search();
	cout << endl << "Printing all information that object of class Group contains: " << endl;
	cout << gr;
	gr.sorting();
	cout << endl << "Sorted array(vector) by the average grade of objects of the Group class: " << endl;
	cout << gr;
	
	cout << endl;
	cin >> gr; //Adding a new student
	gr.sorting();
	cout << gr;
	system("pause");
}
