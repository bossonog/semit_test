#include <iostream>
using namespace std;

class counter {
private:
	static int sum;
	int a;
public:
	counter(int a) : a(a){ sum += a;	}
	int getSum() { return sum; }
	~counter() { sum -= a;}
};
int counter::sum = 0;

int main() {
	counter a(15);
	counter *p = new counter(4);
	cout << a.getSum() << endl; // 19
	delete p;
	cout << a.getSum() << endl; // 15
	system("pause");
}
