#include <iostream>
#include <cmath>
using namespace std;

class fraction {
	static int GCD(int a, int b) {
		a = abs(a);
		b = abs(b);
		while (a&&b) {
			(a > b) ? a %= b : b %= a;
		}
		return a + b;
	}
	static int LCM(int a, int b) {
		return a*b / GCD(a, b);
	}
	friend istream& operator>> (istream& in, fraction& fr) { return in >> fr.num >> fr.den; }
	friend ostream& operator<< (ostream& out, fraction& fr) { return out << fr.num << "/" << fr.den; }
	friend fraction operator+(fraction a, fraction b) {
		int lcm = LCM(a.den, b.den);
		return fraction(a.num*lcm / a.den + b.num*lcm / b.den, lcm);
	}
	friend fraction operator-(fraction a, fraction b) {
		int lcm = LCM(a.den, b.den);
		return fraction(a.num*lcm / a.den - b.num*lcm / b.den, lcm);
	}
	friend fraction& operator*(fraction& a, fraction& b) {
		return fraction(a.num*b.num,a.den*b.den).reduction();
	}
	friend fraction& operator/(fraction& a, fraction& b) {
		return fraction(a.num*b.den, a.den*b.num).reduction();
	}
private:
	int num, den;
public:
	fraction(int num, int den) {
		this->num = num;
		this->den = den;
	}
	fraction& reduction() {
		int gcd = GCD(num, den);
		num /= gcd;
		den /= gcd;
		return *this;
	}
	void setNum(int value) {num = value;}
	void setDen(int value) {den = value;}
	int getNum() { return num; }
	int getDen() { return den; }
};

int main() {
	fraction a(-10, 2);
	fraction b(4, 2);
	fraction c = a + b;
	fraction d = c - a;
	fraction e = c*d;

	cout << "a: " << a << endl;
	cout << "a reducted: " << a.reduction() << endl;
	cout << "b: " << b << endl;
	cout << "c = a+b: " << c << endl;
	cout << "d = c-a: " << d << endl;
	cout << "e = c*d: " << e << endl;
	fraction f(0, 0);
	cout << endl << "Enter num, den space-separated: ";
	cin >> f;
	fraction g = e / f;
	//g.reduction();
	cout << "f: " << f << endl;
	cout << "e/f = " << e << " : " << f << " = " << g << endl;

	system("pause");
}
