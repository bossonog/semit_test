#include <iostream>
using namespace std;
int** arrCreation(int row, int col);

class Matrix {
	friend Matrix& operator*(Matrix& a, int x) {
		for (int i = 0; i < a.row; i++) {
			for (int j = 0; j < a.col; j++) {
				a[i][j] *= x;
			}
		}
		return a;
	}
	friend Matrix& operator*(Matrix& a, Matrix& b) {
		if (a.col != b.row) {
			throw NotMatch(a, b);
		}
		Matrix c(a.row, b.col);
		for (int i = 0; i < a.row; i++) {
			for (int k = 0; k < b.col; k++) {
				int sum = 0;
				for (int j = 0; j < a.col; j++) {
					sum += a[i][j] * b[j][k];
				}
				c.addElem(sum);
			}
		}
		return c;
	}
	friend Matrix& operator+(Matrix& a, Matrix& b) {
		if ((a.row == b.row) && (a.col == b.col)) {
			Matrix c(a.row, a.col);
			for (int i = 0; i < a.row; i++) {
				for (int j = 0; j < a.col; j++) {
					c[i][j] = a[i][j] + b[i][j];
				}
			}
			return c;
		}
		throw NotMatch(a, b);
	}
	friend Matrix& operator-(Matrix& a, Matrix& b) {
		if ((a.row == b.row) && (a.col == b.col)) {
			Matrix c(a.row, a.col);
			for (int i = 0; i < a.row; i++) {
				for (int j = 0; j < a.col; j++) {
					c[i][j] = a[i][j] - b[i][j];
				}
			}
			return c;
		}
		throw NotMatch(a, b);
	}
	friend ostream& operator<<(ostream& out, Matrix& a) {
		for (int i = 0; i < a.row; i++) {
			for (int j = 0; j < a.col; j++) {
				out << a.arr[i][j] << "\t";
			}
			out << endl;
		}
		return out;
	}
	friend Matrix& operator>>(istream &in, Matrix& a) {
		cout << "Enter parameters (rows, columns): ";
		in >> a.row >> a.col;

		a.arr = new int*[a.row];
		for (int i = 0; i < a.row; i++) {
			a.arr[i] = new int[a.col];
			for (int j = 0; j < a.col; j++) {
				a.arr[i][j] = 0;
			}
		}

		a.size = a.row*a.col;
		cout << "Enter " << a.size << " elements in a row" << endl;
		int x;
		for (int i = 0; i < a.size; i++) {
			cin >> x;
			a.addElem(x);
		}
		return a;
	}
private:
	int row, col;
	int** arr;
	int size;
	int count = 0;
	void addElem(int value) {
		arr[count / col][count%col] = value;
		count++;
	}
public:
	int** getArr() { return arr; }
	int getRow() { return row; }
	int getCol() { return col; }
	int getSize() { return size; }
	class NotMatch {
		int row1, row2, col1, col2;
	public:
		NotMatch(Matrix& a, Matrix& b) : row1(a.row), row2(b.row), col1(a.col), col2(b.col) {}
		int getRow1() { return row1; }
		int getRow2() { return row2; }
		int getCol1() { return col1; }
		int getCol2() { return col2; }
	};
	Matrix() { arr = 0; size = 0; }
	Matrix(int row, int col) {
		this->arr=arrCreation(row, col);
		this->row = row;
		this->col = col;
		size = row*col;
	}
	class Proxy {
	private:
		int* _arr;
	public:
		Proxy(int* _arr) {
			this->_arr = _arr;
		}
		int& operator[](int index) {
			return _arr[index];
		}
		~Proxy() {}
	};
	Proxy operator[](int index) {
		return Proxy(arr[index]);
	}
	~Matrix() {
	}
};
void roots(Matrix& a);

int** arrCreation(int row, int col) {
	int** arr = new int*[row];
	for (int i = 0; i < row; i++) {
		arr[i] = new int[col];
		for (int j = 0; j < col; j++) {
			arr[i][j] = 0;
		}
	}
	return arr;
}
void roots(Matrix& a) {
	for (int i = 0; i < a.getRow(); i++) {
		for (int j = 0; j < a.getCol(); j++) {
			if ((i + j) % 2 == 0) a.getArr()[i][j] *= a.getArr()[i][j];
		}
	}
}

int main() {
	Matrix a(3, 2);
	a[2][0] = 5; 
	cout << "Matrix a: " << endl << a << endl;
	roots(a); 
	cout << "Matrix a (changed): " << endl << a << endl;

	Matrix b; 
	cin >> b; 
	cout << "Matrix b: " << endl << b;

	try
	{
		Matrix c = a + b; 
		cout << "Matrix c = a+b: " << endl << c << endl;
	}
	catch (Matrix::NotMatch ex)
	{
		cout << "Not Match " << ex.getRow1() << "x" << ex.getCol1() << " != " << ex.getRow2() << "x" << ex.getCol2() << endl;
	}

	Matrix e(2, 4);
	e[0][0] = 1;
	e[0][1] = 2;
	e[0][2] = 3;
	e[0][3] = 7;
	cout << "Matrix e: " << endl << e << endl;

	Matrix f(3, 3);
	f[0][0] = 1;
	f[1][0] = 2;
	f[0][1] = 5;
	f[2][1] = 6;
	f[2][0] = 3;
	cout << "Matrix f: " << endl << f << endl;
	system("pause");
	try
	{
		Matrix d = e * f; 
		cout << "Matrix d: " << endl << d << endl;
	}
	catch (Matrix::NotMatch ex)
	{
		cout << "Not Match " << ex.getCol1() << "!=" << ex.getRow2() << endl;
	} 
	system("pause");
}
