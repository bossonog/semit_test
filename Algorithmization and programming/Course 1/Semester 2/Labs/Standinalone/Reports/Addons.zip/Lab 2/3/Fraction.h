#ifndef Fraction_h
#define Fraction_h
#include <string>

const char* separator = "/";

class fraction {
	static int GCD(int a, int b) {
		a = abs(a);
		b = abs(b);
		while (a&&b) { (a > b) ? a %= b : b %= a; }
		return a + b;
	}
	static int LCM(int a, int b) {
		return a*b / GCD(a, b);
	}

	friend istream& operator>> (istream& in, fraction& fr) {
		return in >> fr.num >> fr.den; 
	}
	friend ostream& operator<< (ostream& out, fraction& fr) { 
		return out << fr.num << "/" << fr.den; 
	}
	friend fraction operator+(fraction& a, fraction& b) {
		int lcm = LCM(a.den, b.den);
		return fraction(a.num*lcm / a.den + b.num*lcm / b.den, lcm).reduction();
	}
	friend fraction operator-(fraction& a, fraction& b) {
		int lcm = LCM(a.den, b.den);
		return fraction(a.num*lcm / a.den - b.num*lcm / b.den, lcm).reduction();
	}
	friend fraction operator*(fraction& a, fraction& b) {
		return fraction(a.num*b.num, a.den*b.den).reduction();
	}
	friend fraction operator/(fraction& a, fraction& b) {
		return fraction(a.num*b.den, a.den*b.num).reduction(); 
	}
	friend bool operator<(fraction& a, fraction &b) {
		if ((a.den!=0)&&(b.den!=0)&&(a.num / a.den < b.num / b.den)) return true;
		return false;
	}
private:
	int num, den;
public:
	void operator=(int b) {
		setNum(b);
		setDen(b);
	}
	fraction() {};
	fraction& reduction() {
		int gcd = GCD(num, den);
		num /= gcd;
		den /= gcd;
		return *this;
	}
	fraction(int num, int den) : num(num), den(den) {}
	void setNum(int value) { num = value; }
	void setDen(int value) { den = value; }
	int getNum() { return num; }
	int getDen() { return den; }
};

#endif
