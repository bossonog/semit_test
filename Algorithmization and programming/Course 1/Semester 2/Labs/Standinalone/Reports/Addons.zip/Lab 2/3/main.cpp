#include <iostream>
#include "Matrix.h"
#include "Fraction.h"
using namespace std;

fraction minf(fraction** arr, int row, int col) {
	fraction min = arr[0][0];
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			if (arr[i][j] < min) min = arr[i][j];
		}
	}
	return min;
}

int main() {
	Matrix<fraction> f(3,4);
	try {
		f[0][0] = fraction(5, 8);
		f[0][1] = fraction(10, 3);
		f[0][2] = fraction(-4, 3);
		f[1][0] = fraction(12, 19);
		f[2][1] = fraction(5, 8);
		f[16][1] = fraction(5, 8);
	}
	catch (Matrix<fraction>::OutOfBounds ex) {
		cout << "Wrong index: " << "[" << ex.getIndex1() << "]" << "[" << ex.getIndex2() << "]" << endl;
	}

	cout << "Fraction Matrix: " << endl << f << endl;// << "Min: " << min(.getArr(),f.getRow(),f.getCol()) << endl << endl;
//	cout << minf(f.getArr(),f.getRow(),f.getCol());
	Matrix<double> d(2, 4);
	try {
		d[0][0] = 4.1;
		d[0][1] = 3.2;
		d[1][1] = 17.2;
		d[32][-8] = 17.2;
	}
	catch (Matrix<double>::OutOfBounds ex) {
		cout << "Wrong index: " << "[" << ex.getIndex1() << "]" << "[" << ex.getIndex2() << "]" << endl;
	}

	cout << "Double Matrix: " << endl << d << endl << "Min: " << min(d.getArr(), d.getRow(), d.getCol()) << endl << endl;

	Matrix<int> i(3, 4);
	try {
		i[0][0] = 17;
		i[0][1] = -5;
		i[0][2] = 16;
		i[1][0] = 5;
		i[1][2] = 60;
		i[-5][-2] = 60;
	}
	catch (Matrix<int>::OutOfBounds ex) {
		cout << "Wrong index: " << "[" << ex.getIndex1() << "]" << "[" << ex.getIndex2() << "]" << endl;
	}

	cout << "Int Matrix: " << endl << i << endl << "Min: " << min(i.getArr(), i.getRow(), i.getCol()) << endl << endl;

	system("pause");
}
