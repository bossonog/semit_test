#ifndef Derivative_h
#define Derivative_h

class Derivative {
public:
	int n;
	double eps;

	double min_der(double left, double right, double step, int n, double eps);
	double fst_der(double x);
	virtual double function(double x)=0;
};

#endif
