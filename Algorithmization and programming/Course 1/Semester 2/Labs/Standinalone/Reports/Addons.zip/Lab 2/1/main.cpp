#include <iostream>
#include <cstring>
using namespace std;

class Human {
private:
	char name[30];
	int age;
public:
	Human(char* name, int age) {
		strcpy(this->name, name);
		this->age=age;
	}
	virtual void info() {
		cout << endl <<  "Name: " << name << " age: " << age;
	}
	virtual ~Human() {}
};
class Citizen : public Human {
private:
	char location[40];
public:
	Citizen(char* name, int age, char* location) : Human(name, age) {
		strcpy(this->location, location);
	}
	virtual void info() {
		Human::info();
		cout << "\tLocation: " << location;
	}
};
class Student : public Citizen {
public:
	int year;
public:
	Student(char* name, int age, int year, char* location) : Citizen(name,age,location), year(year){}
	virtual void info()  {
		Citizen::info();
		cout << "\tYear of study: " << year;
	}
};
class Coworker : public Human {
private:
	int total;
public:
	Coworker(char* name, int age, int total) : Human(name,age), total(total){}
	virtual void info() {
		Human::info();
		cout << "\tWork togeher: " << total;
	}
};
int main() {
	const int N = 4;
	Human* people[N] = {
		new Human("Mike", 21),
		new Citizen("Michael", 40, "San Andreas"),
		new Student("Nicola", 30, 2, "Nebraska"),
		new Coworker("Steve", 25, 3)
	};
	for (int i = 0; i < N; i++) {
		people[i]->info();
	}
	for (int i = 0; i < N; i++) {
		delete people[i];
	}
	cout << endl;
	system("pause");
}


