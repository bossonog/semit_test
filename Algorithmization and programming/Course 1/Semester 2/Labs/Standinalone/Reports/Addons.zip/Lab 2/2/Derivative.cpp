#include "Derivative.h"
#include <iostream>
using std::cout;
using std::endl;

double Derivative::min_der(double left, double right, double step, int n, double eps=0.0000001){
	this->eps = eps;
	this->n = n;
	double y;
	double temp;
	bool mustFind = false;
	double derivative;
	for (double x = left; x <= right; x += step) {
		y = function(x);
		derivative = fst_der(x);
		if (!mustFind) {
			temp = derivative;
			mustFind = true;
		}
		if (derivative < temp) {
			temp = derivative;
		}
		cout << "X = " << x << "\t Y = " << y << "\t\t Derivative = " << derivative << endl;
	}
	cout << endl;
	return temp;
}
double Derivative::fst_der(double x) {
	return (function(x + eps) - function(x)) / eps;
}
class MyFunction : public Derivative{
public:
	 double function(double x) {
		double y = 0;
		if (x<0) {
			for (int i = 1; i <= (n - 1); i++) {
				for (int j = 1; j <= n; j++) y += x - i + j;
			}
		}
		else
		{
			for (int i = 0; i <= (n - 1); i++)	if (i) y += x / i;
		}
		return y;
	}
};
class Parabola : public Derivative {
public:
	 double function(double x) {
		return x*x;
	}
};

int main() {
	MyFunction d;
	cout << d.min_der(-5, 5, 1, 5) << endl;
	Parabola c;
	cout << c.min_der(-5, 5, 1, 5, 0.01) << endl;
	system("pause");
}
