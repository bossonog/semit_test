#ifndef Array_h
#define Array_h
using std::ostream;
using std::istream;
using std::endl;
using std::cout;
using std::cin;

template <typename T, typename T1> T** arrCreation(T1 row, T1 col) {
	T** arr = new T*[row];
	for (int i = 0; i < row; i++) {
		arr[i] = new T[col];
		for (int j = 0; j < col; j++) {
			arr[i][j] = 0;
		}
	}
	return arr;
}

template <typename T>T min(T** arr, int row, int col) {
	T min = arr[0][0];
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			if (arr[i][j] < min) min = arr[i][j];
		}
	}
	return min;
}

template <typename T> class Matrix {
	friend ostream& operator<<(ostream& out, Matrix<T>& a) {
		for (int i = 0; i < a.row; i++) {
			for (int j = 0; j < a.col; j++) out << a.arr[i][j] << "\t";
			out << endl;
		}
		return out;
	}
	friend Matrix& operator>>(istream &in, Matrix& a) {
		cout << "Enter parameters (rows, columns): ";
		in >> a.row >> a.col;
		a.arr = arrCreation<T>(a.row, a.col);
		a.size = a.row*a.col;
		cout << "Enter " << a.size << " elements in a row" << endl;
		int x;
		for (int i = 0; i < a.size; i++) {
			cin >> x;
			a.addElem(x);
		}
		return a;
	}
	friend Matrix operator*(Matrix& a, int x) {
		for (int i = 0; i < a.row; i++) {
			for (int j = 0; j < a.col; j++) {
				a[i][j] *= x;
			}
		}
		return a;
	}
	friend Matrix operator*(Matrix& a, Matrix& b) {
		if (a.col != b.row) {
			throw NotMatch(a, b);
		}
		Matrix c(a.row, b.col);
		for (int i = 0; i < a.row; i++) {
			for (int k = 0; k < b.col; k++) {
				int sum = 0;
				for (int j = 0; j < a.col; j++) {
					sum += a[i][j] * b[j][k];
				}
				c.addElem(sum);
			}
		}
		return c;
	}
	friend Matrix operator+(Matrix& a, Matrix& b) {
		if ((a.row == b.row) && (a.col == b.col)) {
			Matrix c(a.row, a.col);
			for (int i = 0; i < a.row; i++) {
				for (int j = 0; j < a.col; j++) {
					c[i][j] = a[i][j] + b[i][j];
				}
			}
			return c;
		}
		throw NotMatch(a, b);
	}
	friend Matrix operator-(Matrix& a, Matrix& b) {
		if ((a.row == b.row) && (a.col == b.col)) {
			Matrix c(a.row, a.col);
			for (int i = 0; i < a.row; i++) {
				for (int j = 0; j < a.col; j++) {
					c[i][j] = a[i][j] - b[i][j];
				}
			}
			return c;
		}
		throw NotMatch(a, b);
	}

private:
	int row, col;
	T** arr;
	int size;
	int count = 0;
	void addElem(int value) {
		arr[count / col][count%col] = value;
		count++;
	}
public:
	T** getArr() { return arr; }
	int getRow() { return row; }
	int getCol() { return col; }
	int getSize() { return size; }
	class NotMatch {
		int row1, row2, col1, col2;
	public:
		NotMatch(Matrix& a, Matrix& b) : row1(a.row), row2(b.row), col1(a.col), col2(b.col) {}
		
		int getRow1() { return row1; }
		int getRow2() { return row2; }
		int getCol1() { return col1; }
		int getCol2() { return col2; }
	};
	class OutOfBounds {
		int index1;
		int index2;
	public:
		OutOfBounds(int index1, int index2) : index1(index1), index2(index2){}
		int getIndex1() { return index1; }
		int getIndex2() { return index2; }
	};
	Matrix() { arr = 0; size = 0; }
	Matrix(int row, int col) : row(row), col(col), arr(arrCreation<T>(row, col)), size(row*col){}
	class Proxy {
	private:
		int index1;
		T* _arr;
		int col;
		int row;
	public:
		Proxy(int index1, T* _arr, int row, int col) : index1(index1), _arr(_arr), row(row), col(col) {}
		T& operator[](int index2) {
			if ((index2 < 0) || (index2 >= col) || (index1<0) || (index1>=row)) {
				throw Matrix<T>::OutOfBounds(index1, index2);
			}
			return _arr[index2];
		}
		~Proxy() {}
	};
	Proxy operator[](int index1) {
		return Proxy(index1, arr[index1], row, col);
	}
	~Matrix() {}
};
#endif
