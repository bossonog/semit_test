package test;
import java.util.Scanner;

public class test {
	public static int factorial (int n) {
		int value = 1;
		for (int i=1; i<=n; i++) {
			value*=i;
		}
		return value;
	}
	
	public static int factorial_rec (int n) {
		if (n==0) return 1;
		return n *= factorial_rec(--n);
	}
	
	public static void main(String[] args) {
		System.out.println("Enter n: ");
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		System.out.print("Loop: " + factorial(n) + " Recursion: " + factorial_rec(n));

	}

}
