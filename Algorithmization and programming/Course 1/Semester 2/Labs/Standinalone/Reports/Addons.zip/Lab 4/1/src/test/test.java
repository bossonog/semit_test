package test;
import java.util.Scanner;
import static java.lang.Math.*;

public class test {
	static final int n = 8;
    public static double f(double x) {
        double y=0;
        if (x <= 5) {
            for (int i = 1; i <= n; i++) {
                y += cos(pow((0.2*x-1),i));
            }
        }
        else {
        	y = pow((2*x-9),1.0/3)+7;
        }
        return y;
    }
    public static void printValues (int left, int right, int step) {
    	for (double x=left; x<=right; x+=step) {
    		System.out.println("x = " + x + "\ty = " + f(x));
    	}
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter left, right, step");
        int left = s.nextInt();
        int right = s.nextInt();
        int step = s.nextInt();
//    	int left = 0;
//    	int right = 10;
//    	int step = 1;
    	printValues(left, right, step);
    }

}