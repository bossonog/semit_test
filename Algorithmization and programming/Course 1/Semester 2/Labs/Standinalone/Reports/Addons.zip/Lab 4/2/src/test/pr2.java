package test;
import java.util.Scanner;

public class pr2 {

	public static void Arithmetic(int n) {
		int k = 1;
		for(int i=0; i<n; i++) {
			k*=8;
			System.out.println(k);
		}
	}
	
	public  static void Bitwise(int n) {
		int k=1;
		for(int i=0; i<n; i++) {
			k <<= 3;
			System.out.println(k);
		}
	}
	
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter n: ");
		int n = in.nextInt();
		System.out.println("Arithmetic operations: ");
		Arithmetic(n);
		System.out.println("Bitwise operations: ");
		Bitwise(n);
	}
}
